package com.dynamsoft.camera2;

import android.graphics.Bitmap;
import android.os.AsyncTask;

public class Task extends AsyncTask<Bitmap, Void, Void> {

    public Task() {

    }

    @Override
    protected Void doInBackground(Bitmap... objects) {
        //... do stuff
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
   }
}